package com.connectglobe;

public interface Provider {
	String DRIVER = "com.mysql.jdbc.Driver";
	String CONNECTION_URL = "jdbc:mysql://localhost:3306/connectglobe";
	String USERNAME = "root";
	String PASSWORD = "root";

}