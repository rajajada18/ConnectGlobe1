package com.connectglobe;

public class AdminBean {
	private String uname, upass;

	public String getUsername() {
		return uname;
	}

	public void setUsername(String uname) {
		this.uname = uname;
	}

	public String getUserpass() {
		return upass;
	}

	public void setUserpass(String upass) {
		this.upass = upass;
	}

}
